#ifndef _Temp_Sensor_Board_H_
#define _Temp_Sensor_Board_H_

#define ONE_WIRE_BUS_ONE_PIN A0
#define ONE_WIRE_BUS_TWO_PIN A1
#define DEBUG_RX_PIN 8
#define DEBUG_TX_PIN 9
#endif
